# Marketing Review Kit

Brand-safe, disclosure-clean AI marketing.

For marketing and member-service teams drafting campaigns, plain-language translations, and member communications with reviewer-friendly outputs.

## Included files

- `marketing-playbook.pdf` — Role playbook for safe marketing AI use: campaign briefs, disclosure review, plain-language translation.
- `prompt-strategy-cheat-sheet.pdf` — Prompt pattern for useful, safe, reviewable AI output.
- `template-ai-workflow-sop.pdf` — Template for documenting tool, input, output, review, approval, and retention.
- `template-ai-use-policy-starter.pdf` — Starter AI use policy a team can adapt in an afternoon.

## Recommended first step

Open `START-HERE.pdf` first.
