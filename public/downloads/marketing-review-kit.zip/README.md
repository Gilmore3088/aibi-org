# Marketing Review Kit

Draft fast, review safely - claims, disclosures, and brand voice without skipped checks.

For marketing, product, and compliance teams using AI to draft campaigns, preserve brand voice, and keep claims and disclosures in the review path.

## Included files

- `marketing-playbook.pdf` - Role playbook for brand voice, campaign kits, market listening, reporting, and segment-aware messaging.
- `prompt-strategy-cheat-sheet.pdf` - Reusable prompt strategies for safer campaign drafting and review.
- `template-ai-workflow-sop.pdf` - Workflow template for documenting AI-assisted marketing processes.
- `template-ai-use-policy-starter.pdf` - Starter policy for approved tools, allowed data, review requirements, and escalation triggers.

## Recommended first step

Open `marketing-review-kit-START-HERE.pdf` first.
