# The Bank Marketing AI Review Kit

Draft faster. Verify every claim. Review every disclosure. Retain every campaign decision.

For marketing, product, compliance, and review teams that need campaign briefs, claim source support, disclosure checks, segment approval, compliance sign-off, and retained evidence before AI-assisted copy goes live.

## Included files

- `01-Marketing-AI-Playbook.pdf` — Context guide for campaign controls, marketing red lines, source support, disclosure review, and evidence retention.
- `02-Marketing-Prompt-Cheat-Sheet.pdf` — Marketing-specific prompt patterns for product campaigns, deposit education, social posts, segment variants, disclosure review, and executive reporting.
- `03-Campaign-Intake-Form.docx` — Editable intake form for campaign owner, audience, channel, approved source terms, claims, compliance reviewer, and evidence location.
- `04-Marketing-Claim-Control-Matrix.xlsx` — Editable claim register for claim, offer term, source document, product owner, disclosure requirement, reviewer, approval date, and final copy location.
- `05-AI-Marketing-Review-Checklist.docx` — Pre-publication review checklist with Reg DD, Reg Z, CAN-SPAM, Reg B discouragement, and Fair Housing checkpoints.
- `06-Segment-Approval-Log.xlsx` — Editable log for campaign audience, selection basis, credit/deposit targeting, excluded-group review, reviewer, approval date, and evidence location.
- `07-Channel-Review-Grid.xlsx` — Channel-by-channel grid for copy assets, source checks, disclosure checks, audience/consent review, approval status, and final asset location.
- `08-Campaign-Evidence-Packet.docx` — Evidence packet for campaign brief, source terms, AI draft, edits, approval, final copy, send date, audience, metrics, complaint flags, and retention location.
- `09-AI-Campaign-Workflow-SOP.docx` — Marketing-specific workflow SOP for choosing the campaign, verifying source terms, drafting with AI, reviewing claims/disclosures, approving audience, and retaining evidence.
- `10-Governance-Appendix-AI-Use-Policy-Starter.pdf` — Governance appendix policy starter for tool, data, review, incident, and ownership rules.

## Recommended first step

Open `00-Start-Here.pdf` first.

## Use sequence

1. Choose one campaign and complete the Campaign Intake Form before prompting.
2. Draft with the Bank Marketing Prompt Cheat Sheet using only approved source terms.
3. Run claims, disclosures, channel, and segment review before approval.
4. Save the Campaign Evidence Packet with source terms, AI draft, edits, approvals, final copy, send date, audience, metrics, complaint flags, and retention location.
5. Keep the AI Use Policy Starter as governance appendix material, not the headline workflow.
