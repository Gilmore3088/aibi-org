# The Frontline AI Enablement Kit

Desk cards, prompts, and manager tools for safer branch and contact-center AI use.

For branch managers, contact-center leaders, training teams, and frontline staff who need to reduce typing, improve follow-up, coach faster, and protect customer data without turning AI into the banker.

## Included files

- `01-Frontline-Data-Handling-Card.pdf` — Desk boundary card for what frontline teams can and cannot put into AI tools.
- `02-Before-You-Paste-Safe-AI-Checklist.pdf` — The four staff habits: strip sensitive data, ask clearly, fact-check, and escalate risky decisions.
- `03-Prompt-Strategy-Cheat-Sheet.pdf` — Prompt pattern for safe, useful, reviewable AI output.
- `04-Retail-Branch-Manager-Guide.pdf` — Manager guide for choosing, reviewing, and scaling frontline AI workflows.
- `05-Branch-Style-Brief-Template.docx` — Editable branch tone, phrase, empathy, escalation, and compliance reminder template.
- `06-First-Draft-Reply-Library.docx` — Editable starter patterns for document requests, appointment follow-ups, service recovery, status updates, branch closures, card delays, and check-hold explanations.
- `07-Procedure-to-Job-Aid-Prompt.docx` — Prompt template for turning approved procedures into frontline job aids without inventing policy.
- `08-Branch-Coaching-Scenario-Pack.docx` — Fictional coaching scenarios by difficulty level with manager questions and escalation prompts.
- `09-Customer-Voice-Report-Template.docx` — Template for de-identified complaint themes, FAQ clusters, branch friction, and call-center patterns.
- `10-Retail-AI-Evidence-Packet.docx` — Evidence packet for use case, approved prompt, data class, output, reviewer, final version, retention location, and metric.
- `11-30-Day-Frontline-Rollout-Tracker.xlsx` — Editable manager tracker for data boundary, first-draft replies, coaching scenarios, customer-signal reporting, and scale decision.

## Recommended first step

Open `00-Start-Here.pdf` first.

## Use sequence

1. Give every teammate the Frontline Data Handling Card.
2. Train the four Before-You-Paste Safe AI habits.
3. Use the Prompt Strategy Cheat Sheet for first drafts and [VERIFY] checks.
4. Managers use the Retail Branch Manager Guide to pick one frontline workflow.
5. Save approved prompts, outputs, reviews, and rollout decisions into the branch toolkit.
