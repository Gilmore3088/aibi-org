# Frontline Enablement Kit

What every branch and contact-center teammate needs at their desk.

For retail, branch, and contact center teams using AI to reduce typing, improve follow-up, summarize calls, and coach staff without exposing customer data.

## Included files

- `retail-playbook.pdf` — Role playbook for safe frontline AI use: summaries, replies, coaching, training, and customer signal.
- `safe-ai-use-checklist.pdf` — Staff-facing safety habits before using any AI tool.
- `prompt-strategy-cheat-sheet.pdf` — Prompt pattern for useful, safe, reviewable AI output.
- `data-handling-reference-card.md` — Desk reference for what data can and cannot be used with AI tools.

## Recommended first step

Open `START-HERE.pdf` first.
