# Data Handling Reference Card

## The rule

Strip the specifics. Keep the structure.

If you would not be comfortable seeing the prompt outside the institution, do not paste it into an unapproved AI tool.

## Green: usually safe

Use synthetic, public, or generic information.

Examples:

- Public regulatory guidance
- Synthetic training scenarios
- Blank templates
- Internal huddle topics with no confidential information
- Generic product education language

## Yellow: approved tool and human review

Use only approved tools, redaction, and review.

Examples:

- Internal procedure summaries
- Customer-facing draft language using placeholders
- De-identified call notes
- Aggregated customer themes
- Campaign drafts with review before use

## Red: do not use public AI tools

Use a controlled enterprise workflow only if approved.

Examples:

- Customer names
- Account numbers
- Balances
- Transaction details
- SSNs / DOBs / addresses
- Credit decisions or adverse action reasoning
- SAR narratives or AML case details
- Fraud or authentication workflows
- Legal or compliance determinations
- API keys, passwords, tokens, or secrets

## Safe placeholders

Use placeholders instead of real data:

- [CUSTOMER]
- [ACCOUNT TYPE]
- [ACCOUNT NUMBER]
- [DATE]
- [AMOUNT]
- [PRODUCT]
- [BRANCH]
- [DOCUMENT]
- [NEXT STEP]
- [REVIEWER]

## Before you paste

1. What data is in this prompt?
2. Who could be affected by the output?
3. What happens if the AI is confidently wrong?
4. Who reviews the output before use?
