# The Bank AI Governance Starter Kit

Four tools to set the data line, classify AI use, start the inventory, and document your first workflow.

For compliance, risk, operations, and executive teams establishing the first approved AI path: publish safe-use habits, classify use cases, start the inventory, and document one reusable workflow.

## Included files

- `01-Before-You-Paste-Safe-AI-Checklist.pdf` — What staff should do before using AI: strip sensitive data, ask clearly, fact-check outputs, and escalate risky decisions.
- `02-Red-Yellow-Green-AI-Use-Card.pdf` — How to classify an AI use case as allowed, review-required, or prohibited before work begins.
- `03-AI-Use-Case-Inventory-Card.pdf` — Quick reference for logging AI workflows, owners, data classes, risk tiers, vendor controls, and review cadence.
- `04-AI-Use-Case-Inventory.xlsx` — Editable portfolio register for status, department, purpose, tool approval, data class, risk tier, customer impact, reviewer, evidence, and review dates.
- `05-AI-Workflow-SOP-Template.pdf` — Reference PDF for documenting an individual AI-assisted workflow before reuse.
- `06-AI-Workflow-SOP-Builder.docx` — Editable workflow SOP builder with approved tool, allowed inputs, prohibited inputs, review standard, approval checkpoint, retention rule, and escalation triggers.

## Recommended first step

Open `00-Start-Here.pdf` first.

## Use sequence

1. Set the data line with the Before-You-Paste Safe AI Checklist.
2. Classify three current AI uses with the Red / Yellow / Green AI Use Card.
3. Start the editable AI Use-Case Inventory with owner, data class, risk tier, human review, evidence, and next review date.
4. Use the Workflow SOP Builder before any AI workflow becomes repeatable team practice.
5. Run the 45-Minute AI Governance Starter Sprint: set the data line, classify three current AI uses, start the inventory, and document one workflow SOP.
