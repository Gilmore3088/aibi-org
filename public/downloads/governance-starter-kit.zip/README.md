# Governance Starter Kit

First 30 days of governing AI tool use.

For compliance, risk, and executive teams establishing the first approved AI path: rules, staff safety, use-case inventory, and workflow documentation.

## Included files

- `safe-ai-use-checklist.pdf` — Staff-facing habits before using AI: strip data, ask clearly, fact-check, escalate.
- `red-yellow-green-use-card.pdf` — Ten-second classification card for safe, review-required, and prohibited AI uses.
- `template-ai-workflow-sop.pdf` — Template for documenting tool, input, output, review, approval, and retention.
- `ai-use-case-inventory.md` — Working register for AI use cases, data classes, risk tiers, reviewers, and review cadence.

## Recommended first step

Open `START-HERE.pdf` first.
