# Governance Starter Kit

Start here - first 30 days of governing AI tool use.

For compliance, risk, and executive teams establishing the first approved AI path: rules, staff safety, use-case inventory, and workflow documentation.

## Included files

- `safe-ai-use-checklist.pdf` - Staff-facing habits before using AI: strip data, ask clearly, fact-check, escalate.
- `red-yellow-green-use-card.pdf` - Ten-second classification card for safe, review-required, and prohibited AI uses.
- `ai-use-case-inventory.md` - Working register for AI use cases, data classes, risk tiers, reviewers, and review cadence.
- `template-ai-workflow-sop.pdf` - Template for documenting tool, input, output, review, approval, and retention.

## Recommended first step

Open `governance-starter-kit-START-HERE.pdf` first.
