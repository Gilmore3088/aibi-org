# Governance Starter Kit

First 30 days of governing AI tool use.

For compliance, risk, and executive teams establishing the first approved AI path: rules, staff safety, use-case inventory, and workflow documentation.

## Included files

- `safe-ai-use-checklist.pdf` — Staff-facing habits before using AI: strip data, ask clearly, fact-check, escalate.
- `red-yellow-green-use-card.pdf` — Ten-second classification card for safe, review-required, and prohibited AI uses.
- `artifact-ai-use-case-inventory.pdf` — One-page AI use-case inventory card for owners, data classes, risk tiers, vendor controls, and review cadence.
- `template-ai-workflow-sop.pdf` — Template for documenting tool, input, output, review, approval, and retention.
- `artifact-ai-use-case-inventory-spreadsheet.xlsx` — Editable spreadsheet companion for maintaining owner, data class, risk tier, vendor status, human review, evidence retained, and next review date.

## Recommended first step

Open `START-HERE.pdf` first.
