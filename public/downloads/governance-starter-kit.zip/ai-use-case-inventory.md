# AI Use-Case Inventory

Use this register to document every AI use case in the institution. Start simple. A current working sheet beats a perfect missing framework.

| Use case | Department | Tool | Data class | Risk tier | Human reviewer | Status | Last reviewed | Evidence location |
|---|---|---|---|---|---|---|---|---|
| Draft internal training summary | HR / Training | Approved AI assistant | Internal | Yellow | Training manager | Proposed |  |  |
| Summarize branch FAQ themes | Retail | Approved AI assistant | Redacted / aggregate | Yellow | Retail operations lead | Proposed |  |  |
| Generate synthetic BSA training cases | BSA / AML | Approved AI assistant | Synthetic | Green | BSA officer | Proposed |  |  |

## Field guide

- **Use case:** Plain-English description of the task.
- **Department:** Business owner.
- **Tool:** Vendor, product, model, or approved platform.
- **Data class:** Public, internal, confidential, customer NPI, SAR-restricted, security-sensitive.
- **Risk tier:** Green, Yellow, or Red.
- **Human reviewer:** Person or role that approves output before use.
- **Status:** Proposed, piloting, approved, conditional, retired.
- **Last reviewed:** Date of most recent review.
- **Evidence location:** Link or repository path for supporting records.

## Minimum review rule

Any use case that could affect a customer, examiner, policy, control, financial decision, complaint, credit action, fraud workflow, BSA/AML workflow, or retained business record needs a named human reviewer before use.
