# Lending Review Kit

Adverse-action, fair-lending, and decision packets that stay traceable.

For lending, credit, and compliance teams using AI to improve language, organize decision packets, and protect file-specific principal reasons.

## Included files

- `lending-playbook.pdf` - Role playbook for adverse-action language, borrower summaries, fair-lending checks, and decision packets.
- `fair-lending-ai-review-checklist.md` - Checklist for AI-assisted lending workflows, adverse action, alternative data, and bias review.
- `ai-use-case-inventory.md` - Register template for documenting AI lending use cases, reviewers, and risk tiers.
- `template-ai-workflow-sop.pdf` - Workflow SOP template for AI-assisted lending tasks.

## Recommended first step

Open `lending-review-kit-START-HERE.pdf` first.
