# The Lending AI Review Kit

Four tools to review AI-assisted credit workflows before they touch decisions, adverse action, or customer-facing explanations.

For lending, credit, and compliance teams reviewing one AI-assisted workflow and proving the decision stayed human, explainable, fair-lending aware, and file-supported.

## Included files

- `01-Lending-AI-Control-Playbook.pdf` — Context guide for safe lending AI controls, adverse-action support, decision packets, and human accountability.
- `02-Lending-AI-Use-Case-Register.xlsx` — Editable lending register with product line, decision influence, adverse-action involvement, customer-facing output, principal-reason traceability, review requirements, and packet location.
- `03-Fair-Lending-AI-Review-Checklist.pdf` — Reviewer checklist for AI-assisted credit workflows, adverse-action explainability, protected-basis outcome-gap monitoring, proxy risk, and recurring review.
- `04-Fair-Lending-AI-Review-Worksheet.xlsx` — Editable worksheet for population, sample, protected bases, proxy methodology, baseline, materiality threshold, remediation owner, adverse-action review, and next review date.
- `05-Principal-Reason-Traceability-Table.xlsx` — Trace each principal reason to source file evidence, human reviewer, AI draft use, unsupported language removal, final language, and retention location.
- `06-Adverse-Action-AI-Review-Log.xlsx` — Track each AI-assisted adverse-action drafting or review instance with reviewer, notice location, exception, and escalation notes.
- `07-Lending-Workflow-SOP-Template.docx` — Editable lending-native SOP for approved tool, allowed inputs, prohibited inputs, AI may/may-not boundaries, review, evidence, and current model-risk source language.
- `08-Decision-Packet-Evidence-Index.docx` — Checklist for source documents, AI output, reviewer edits, final memo or notice, approval, and retention location.

## Recommended first step

Open `00-Start-Here.pdf` first.

## Use sequence

1. Choose one lending AI workflow and log it in the Lending AI Use-Case Register.
2. Run the fair-lending and adverse-action review before reuse.
3. Complete the Principal Reason Traceability Table whenever adverse-action language is involved.
4. Document the workflow in the Lending Workflow SOP Template.
5. Save the Decision Packet Evidence Index with source documents, AI output, reviewer edits, approval, final notice, and retention location.
