# Lending Review Kit

Reviewable AI for the lending desk.

For lending and credit teams reviewing AI-assisted denials, decisions, and adverse-action notices with documented human checks.

## Included files

- `lending-playbook.pdf` — Role playbook for safe lending AI use: adverse-action tuner, decision summaries, fair-lending pre-checks.
- `template-ai-workflow-sop.pdf` — Template for documenting tool, input, output, review, approval, and retention.
- `fair-lending-ai-review-checklist.md` — Reviewer checklist for fair-lending and disparate-impact concerns on AI-assisted decisions.
- `ai-use-case-inventory.md` — Working register for AI use cases, data classes, risk tiers, reviewers, and review cadence.

## Recommended first step

Open `START-HERE.pdf` first.
