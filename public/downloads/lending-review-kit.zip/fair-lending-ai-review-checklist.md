# Fair-Lending AI Review Checklist

Use this checklist before adopting any AI-assisted workflow that touches lending, credit, eligibility, pricing, underwriting, adverse action, targeting, or borrower-facing explanation.

## 1. Use-case scope

- [ ] Business purpose is documented.
- [ ] Workflow owner is named.
- [ ] AI tool or model is identified.
- [ ] Output type is clear: draft, summary, score, recommendation, or decision support.
- [ ] Human reviewer is named.

## 2. Data review

- [ ] Input data sources are documented.
- [ ] Customer data class is identified.
- [ ] Protected-class variables are excluded unless legally required and governed.
- [ ] Proxy-variable risk has been considered.
- [ ] Alternative data has independent, explainable value.

## 3. Adverse action control

- [ ] AI does not invent principal reasons.
- [ ] Principal reasons trace to the file.
- [ ] Final adverse action language is human-approved.
- [ ] Generic denial language has been removed.
- [ ] The reviewer can explain the reason to an applicant or examiner.

## 4. Bias and impact review

- [ ] Disparate impact risk has been assessed.
- [ ] Override patterns are monitored.
- [ ] Exception rates are reviewed.
- [ ] Outcome differences are reviewed where legally and operationally appropriate.
- [ ] Any high-risk model has validation and monitoring requirements.

## 5. Evidence packet

Retain:

- use-case intake form
- tool approval status
- data classification
- prompt or model instruction
- source material description
- AI output
- reviewer changes
- final approved output
- approval date
- next review date
