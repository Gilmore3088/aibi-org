# The AI Prompting Foundation Kit

Turn a vague AI request into a safe, structured, reviewable banker prompt with placeholders, output format, and human review.

For bankers, managers, analysts, trainers, marketers, lenders, operations teams, and compliance reviewers who want useful AI support without leaking sensitive data, skipping review, or letting AI make decisions.

## Included files

- `01-Prompting-Foundation-Guide.pdf` — Foundation guide for prompt types, safe placeholders, output formats, Green/Yellow/Red lanes, examples, and review habits.
- `02-Banker-Prompt-Formula-Card.pdf` — One-page prompt formula reference: role, task, source, constraints, output, verify, and escalate.
- `03-Safe-Prompt-Placeholder-Card.pdf` — Reference card for replacing customer, account, transaction, complaint, credit, BSA/AML, and security details before prompting.
- `04-Prompt-Output-Review-Checklist.pdf` — Checklist for verifying source accuracy, placeholder use, [VERIFY] items, review ownership, escalation, and retained evidence before downstream use.
- `05-Prompt-Library.docx` — Editable role-specific prompt examples for retail, operations, marketing, lending, BSA/AML, compliance, training, and executive use.
- `06-Reusable-AI-Working-Brief.docx` — Editable working brief for turning a useful one-off prompt into a shared team prompt with owner, reviewer, data boundary, escalation, and evidence fields.
- `07-Reusable-AI-Working-Brief-Copy-Paste.txt` — Plain-text copy/paste template for moving the prompt brief into an internal ticket, toolkit entry, or SOP draft.
- `08-Workflow-SOP-Next-Step.pdf` — Downstream SOP template for documenting approved AI-assisted workflows before repeatable team use.
- `09-Before-You-Paste-Safe-AI-Checklist.pdf` — Four safe-use habits that sit underneath the prompt foundation: strip sensitive data, ask clearly, fact-check, and escalate.
- `10-Red-Yellow-Green-AI-Use-Card.pdf` — Risk classification reference for allowed, review-required, and prohibited AI use cases.
- `11-Design-Dev-Handoff-Brief.docx` — Designer/developer handoff brief for the Prompting Foundation product, prompt builder flow, data model, and acceptance criteria.

## Recommended first step

Open `00-Start-Here.pdf` first.

## Use sequence

1. Read the Prompting Foundation Guide and teach the Banker Prompt Formula.
2. Use the Placeholder Card before anyone pastes source material into an AI tool.
3. Open /resources/prompting-foundation to assemble a prompt from structured fields.
4. Use the Prompt Library for role-specific examples, then adapt with placeholders.
5. Complete the Output Review Checklist before output moves downstream.
6. If a prompt becomes repeatable team practice, move it into the Reusable AI Working Brief and then the Workflow SOP Builder.
