# Prompt Like a Banker Kit

Turn a vague AI request into a safe, structured, review-ready banker prompt with placeholders, output format, and human review.

For bankers, managers, analysts, trainers, marketers, lenders, operations teams, and compliance reviewers who want useful AI support without leaking sensitive data, skipping review, or letting AI make decisions.

## Included files

- `01-Prompt-Like-A-Banker-Prompt-Card.pdf` — Three-page prompt card for the 5-line prompt method, data line, placeholders, examples, and review checks.
- `02-Banker-Prompt-Formula-Card.pdf` — One-page prompt formula reference: role, task, source, constraints, output, verify, and escalate.
- `03-Safe-Prompt-Placeholder-Card.pdf` — Reference card for replacing customer, account, transaction, complaint, credit, BSA/AML, and security details before prompting.
- `04-Banker-Prompt-Types-Cheat-Sheet.pdf` — Prompt type menu for draft, summarize, rewrite, extract, compare, checklist, critique, scenario, data-to-narrative, and solution brief prompts.
- `05-Safe-vs-Unsafe-Prompt-Examples.pdf` — Unsafe and safer banker prompt examples for customer service, credit, BSA/AML, marketing, examiner-facing, and operations use cases.
- `06-Prompt-Output-Review-Checklist.pdf` — Checklist for verifying source accuracy, placeholder use, [VERIFY] items, review ownership, escalation, and retained evidence before downstream use.
- `07-Prompt-Library.docx` — Editable role-specific prompt examples for retail, operations, marketing, lending, BSA/AML, compliance, training, and executive use.
- `08-Reusable-AI-Working-Brief.docx` — Editable working brief for turning a useful one-off prompt into a shared team prompt with owner, reviewer, data boundary, escalation, and evidence fields.
- `09-Reusable-AI-Working-Brief-Copy-Paste.txt` — Plain-text copy/paste template for moving the prompt brief into an internal ticket, toolkit entry, or SOP draft.
- `10-Workflow-SOP-Next-Step.pdf` — Downstream SOP template for documenting approved AI-assisted workflows before repeatable team use.
- `11-Before-You-Paste-Safe-AI-Checklist.pdf` — Four safe-use habits that sit underneath the prompt foundation: strip sensitive data, ask clearly, fact-check, and escalate.
- `12-Red-Yellow-Green-AI-Use-Card.pdf` — Risk classification reference for allowed, review-required, and prohibited AI use cases.
- `13-Design-Dev-Handoff-Brief.docx` — Designer/developer handoff brief for the Prompting Foundation product, prompt builder flow, data model, and acceptance criteria.

## Recommended first step

Open `00-Start-Here.pdf` first.

## Use sequence

1. Read the Prompt Like a Banker Prompt Card and teach the 5-line banker prompt.
2. Use the Placeholder Card before anyone pastes source material into an AI tool.
3. Use the Prompt Types Cheat Sheet to choose the work before writing the prompt.
4. Review the Safe vs. Unsafe Prompt Examples before teams write customer, credit, BSA/AML, or examiner-facing prompts.
5. Open /resources/prompting-foundation to assemble a prompt from structured fields.
6. Use the Prompt Library for role-specific examples, then adapt with placeholders.
7. Complete the Output Review Checklist before output moves downstream.
8. If a prompt becomes repeatable team practice, move it into the Reusable AI Working Brief and then the Workflow SOP Builder.
