# The Banker Builder Brief Kit

In 45 minutes, turn one workflow problem into a one-page Builder Brief, safe build path, test plan, and launch checklist.

For operations, branch, compliance, risk, IT, and executive teams that want bankers to turn one annoying workflow into a specific, reviewable internal solution plan before it becomes shadow IT.

## Included files

- `01-Banker-Builder-Guide.pdf` — Plain-language guide for turning workflow pain into a build/no-build decision, Builder Brief, safe path, test plan, and handoff.
- `02-Should-We-Build-This-Scorecard.xlsx` — Editable scorecard with yes/no questions, live score, verdict, recommended action, reviewer notes, and evidence location.
- `03-Banker-Builder-Brief.docx` — One-page PRD-style banker brief for problem, user, current workflow, proposed solution, must-do items, must-not-do boundaries, data, review, evidence, and handoff.
- `04-Build-Path-And-Risk-Gate.xlsx` — Editable build-path ladder and data/risk gate workbook with Green, Yellow, Red logic and escalation prompts.
- `05-Prototype-Test-Plan.docx` — Three-user prototype test plan with permitted test data, acceptance criteria, failure modes, reviewer checks, and final decision.
- `06-Launch-And-Handoff-Checklist.docx` — Launch and handoff checklist for owner, backup owner, access, support, version, review date, evidence, retention, pause triggers, and kill switch.
- `07-Safe-First-Builds-Menu.pdf` — Curated menu of low-risk first builds such as job-aid builders, handoff summaries, review checklists, evidence packets, training scenarios, and issue trackers.
- `08-Builder-Brief-Markdown-Export-Template.md` — Markdown export pattern for copying the final Builder Brief into an internal ticket, review packet, or handoff note.
- `09-Workflow-SOP-Next-Step.pdf` — Downstream SOP template for documenting approved AI-assisted workflows before repeatable team use.
- `10-Operations-AI-Workflow-Kit.pdf` — Operations playbook context for turning a useful shortcut into something someone else can run, review, measure, and hand off.
- `11-Red-Yellow-Green-AI-Use-Card.pdf` — Risk classification reference for allowed, review-required, and prohibited AI use cases.
- `12-InfoSec-AI-Control-Plane-Kit.pdf` — InfoSec reference for routing, inspecting, logging, gating, and governing AI traffic before shadow AI becomes architecture.
- `13-Design-Dev-Handoff-Brief.docx` — Scrubbed designer/developer handoff brief for the future interactive Builder Brief experience.

## Recommended first step

Open `00-Start-Here.pdf` first.

## Use sequence

1. Read the Banker Builder Guide and complete the Should We Build This? Scorecard.
2. Complete the Banker Builder Brief before prompting, tracking, automating, or asking IT for a build.
3. Use the Build Path Selector and Risk Gate to choose the smallest safe path and catch Red triggers early.
4. Run the Prototype Test Plan with permitted test data and a named reviewer.
5. Complete the Launch and Handoff Checklist before reuse.
6. If the workflow becomes repeatable, move it into the AI Workflow SOP Builder.
